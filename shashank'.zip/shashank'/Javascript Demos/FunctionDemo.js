// function product(a,b)
// {
//     return(a*b);
// }
number1=100;
function PrintValue()
{
    var number1=10;
    return(number1);
}
function PrintValue2()
{
    return(number1);
}