var num1=20
var str1="abc"
var bool1=true
var num2=null;
var var1;
document.write("type of str1: "+typeof(str1)+"<br>");
document.write("type of num1: "+typeof(num1)+"<br>");
document.write("type of bool1: "+typeof(bool1)+"<br>");
document.write("type of num2: "+typeof(num2)+"<br>");
document.write("type of var1: "+typeof(var1)+"<br>");